package com.example.aanchu.sqa_calculator;

public class Calculator {
    public double addition(double i, double j){
        return (i+j);
    }
    public double subtraction(double i, double j){
        return (i-j);
    }
    public double multiplication(double i, double j){
        return (i*j);
    }
    public double division(double i, double j){
        return (i*j);
    }
}
