package com.example.aanchu.sqa_calculator;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnAddition=null;
    Button btnSubtraction=null;
    Button btnMultiply=null;
    Button btnDivide=null;
    Button btnClearAll=null;
    TextView result=null;
    EditText edtxt1=null;
    EditText edtxt2=null;
    Calculator c=new Calculator();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        values();
    }
    public void values()
    {
        edtxt1 = findViewById(R.id.edtxt1);
        edtxt2=findViewById(R.id.edtxt2);
        btnAddition=findViewById(R.id.btnAddition);
        btnSubtraction=findViewById(R.id.btnSubtraction);
        btnMultiply=findViewById(R.id.btnMultiply);
        btnDivide=findViewById(R.id.btnDivision);
        btnClearAll=findViewById(R.id.btnClearAll);
        result=findViewById(R.id.result);
        btnAddition.setOnClickListener(this);
        btnSubtraction.setOnClickListener(this);
        btnMultiply.setOnClickListener(this);
        btnDivide.setOnClickListener(this);
        btnClearAll.setOnClickListener(this);

    }


    @Override
    public void onClick(View view) {
        double value1,value2;

        value1 = Double.parseDouble(edtxt1.getText().toString());
        value2 = Double.parseDouble(edtxt2.getText().toString());
        switch (view.getId())
        {
            case R.id.btnAddition:
                double addition =c.addition(value1,value2);
                result.setText(String.valueOf(addition));
                break;
            case R.id.btnSubtraction:
                double subtraction =c.subtraction(value1,value2);
                result.setText(String.valueOf(subtraction));
                break;
            case R.id.btnMultiply:
                double multiplication =c.multiplication(value1,value2);
                result.setText(String.valueOf(multiplication));
                break;
            case R.id.btnDivision:

                    double division = c.division(value1,value2);
                    result.setText(String.valueOf(division));

                break;
            case R.id.btnClearAll:
                edtxt1.setText("");
                edtxt2.setText("");
                result.setText("");
        }

    }
}
