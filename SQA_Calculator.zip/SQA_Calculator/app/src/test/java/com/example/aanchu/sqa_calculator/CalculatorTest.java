package com.example.aanchu.sqa_calculator;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class CalculatorTest {
    //Member variable
    Calculator c;
    @Before
    public void setUp() throws Exception {

        //Initialized member variable
        c = new Calculator();
    }
        // TEST CASES FOR ADDITION

        @Test
        // Test case:add1
        //the inputs are 10 and 10
        //output 100

        public void testAddition_input10and10_output100() throws Exception {
            // 1. Arrange
            double i = 10;
            double j = 10;

            // 2. Act
            double result = c.addition(i, j);

            // 3. Assert
            assertEquals(20.0, result,1);
        }

    @Test
    // Test case:add2
    //the inputs are -10 and -10
    //output 100

    public void testAddition_negative10andnegative10_outputnegative20point0() throws Exception {
        // 1. Arrange
        double i = -10;
        double j = -10;

        // 2. Act
        double result = c.addition(i, j);

        // 3. Assert
        assertEquals(-20.0, result,1);
    }
        @Test

        // Test case:add3
        //the inputs are -2.0 and -10
        //output -12.0

        public void testAddition_negative2point0andnegative10_output8point0() throws Exception {
            // 1. Arrange
            double i = -2.0;
            double j = -10;

            // 2. Act
            double result = c.addition(i, j);

            // 3. Assert
            assertEquals(-12.0, result,1);
        }




        // TEST CASES FOR SUBTRACTION

        @Test
        // Test case: sub1
        //inputs are 10 and 8
        //output is 2


        public void testSubtraction_10and8_2point0() throws Exception {
            // 1. Arrange
            double i = 10;
            double j = 8;

            // 2. Act
            double result = c.subtraction(i, j);

            // 3. Assert
            assertEquals(2.0, result,1);
        }

        @Test
        // Test case: sub2
        // inputs are -5 and -5
        //output 0

        public void testSubtraction_negative5Andnegative5_0point0() throws Exception {
            // 1. Arrange
            double i = -5;
            double j = -5;

            // 2. Act
            double result = c.subtraction(i, j);

            // 3. Assert
            assertEquals(0.0, result,1);
        }



        @Test
        // Test case sub3
        //input are 0 nd -0.25
        //output 0.25


        public void testSubtraction_0andNegativePoint25_Point25() throws Exception {
            // 1. Arrange
            double i = 0;
            double j = -0.25;

            // 2. Act
            double result = c.subtraction(i, j);

            // 3. Assert
            assertEquals(0.25, result,1);
        }



        // TEST CASES FOR MULTIPLICATION

        @Test
        // Test case mul1
        //input are 0 nd 0
        //output 0


        public void testMultiplication_0And0_0point0() throws Exception {
            // 1. Arrange
            double i = 0;
            double j = 0;

            // 2. Act
            double result = c.multiplication(i, j);

            // 3. Assert
            assertEquals(0.0, result,1);
        }

        @Test
    // Test case mul2
    //input are -10nd -3
    //output 30.0


    public void testMultiplication_Negative10_Negative3_Positive30() throws Exception {
            // 1. Arrange
            double i = -10;
            double j = -3;

            // 2. Act
            double result = c.multiplication(i, j);

            // 3. Assert
            assertEquals(30.0, result,1);
        }


        @Test
    // Test case mul3
    //input are 6nd -3
    //output -18.0

    public void testMultiplication_6AndNegative3_negative18point0() throws Exception {
            // 1. Arrange
            double i = 6;
            double j = -3;

            // 2. Act
            double result = c.multiplication(i, j);

            // 3. Assert
            assertEquals(-18.0, result,1);
        }





    // TEST CASES FOR DIVISION

    @Test
    // Test case div1
    //input are 30 nd 5
    //output 6.0


    public void testDivision_30and5_6point0() throws Exception {
        // 1. Arrange
        double i = 30;
        double j = 5;

        // 2. Act
        double result = c.division(i, j);

        // 3. Assert
        assertEquals(6.0, result,1);
    }


    @Test
    // Test case div2
    //input are 0 nd 10
    //output 0

    public void testDivision_0And10_0() throws Exception {
        // 1. Arrange
        double i = 0;
        double j = 10;

        // 2. Act
        double result = c.division(i, j);

        // 3. Assert
        assertEquals(0.0, result,1);
    }


    @Test
    // Test case div3
    //input are -2.5 nd -2.5
    //output 1


    public void testDivision_Negative2point5AndNegative2point5_1point0() throws Exception {
        // 1. Arrange
        double i = -2.5;
        double j = -2.5;

        // 2. Act
        double result = c.division(i, j);

        // 3. Assert
        assertEquals(1, result,1);
    }

    // TEST CASES FOR DIVISION after mutation

    @Test
    // Test case div1
    //input are 1 nd 1
    //output 1


    public void testDivision_1and1_1() throws Exception {
        // 1. Arrange
        double i =1;
        double j = 1;

        // 2. Act
        double result = c.division(i, j);

        // 3. Assert
        assertEquals(1, result,1);
    }


    @Test
    // Test case div2
    //input are 2 nd 1
    //output 2

    public void testDivision_2And1_2() throws Exception {
        // 1. Arrange
        double i = 2;
        double j = 1;

        // 2. Act
        double result = c.division(i, j);

        // 3. Assert
        assertEquals(2, result,1);
    }


    @Test
    // Test case div3
    //input are 9 nd 3
    //output 1


    public void testDivision_9And3_3() throws Exception {
        // 1. Arrange
        double i = 9;
        double j = 3;

        // 2. Act
        double result = c.division(i, j);

        // 3. Assert
        assertEquals(3, result,1);
    }




}